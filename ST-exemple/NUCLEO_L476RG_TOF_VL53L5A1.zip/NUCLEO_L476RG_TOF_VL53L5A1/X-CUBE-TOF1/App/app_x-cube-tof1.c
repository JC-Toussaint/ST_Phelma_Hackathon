/**
  ******************************************************************************
  * @file          : app_x-cube-tof1.c
  * @author        : IMG SW Application Team
  * @brief         : This file provides code for the configuration
  *                  of the STMicroelectronics.X-CUBE-TOF1.2.0.0 instances.
  ******************************************************************************
  *
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "app_x-cube-tof1.h"
#include "main.h"
#include <stdio.h>

#include "53l5a1_ranging_sensor.h"
#include "app_tof_pin_conf.h"

#include "NanoEdgeAI.h"

/*
 * The purpose of this sample application is to showcase the threshold detection
 * functionality of this device.
 *
 * When the device detects a target that match the configuration an IT is generated
 * and the host will start printing the measurement information on the serial connection (UART).
 *
 * Here is the default configuration:
 *
 * ITConfig.Criteria = RS_IT_IN_WINDOW;
 * ITConfig.LowThreshold = 200; // distance in mm
 * ITConfig.HighThreshold = 600; // distance in mm
 *
 * Other availables interrupt generation criteria for this device are:
 *
 * - RS_IT_DEFAULT          // IT if new measurement is ready (no thresholds)
 * - RS_IT_IN_WINDOW        // IT if distance > thresh_high
 * - RS_IT_OUT_OF_WINDOW    // IT if distance < LowThreshold OR distance > HighThreshold
 * - RS_IT_BELOW_LOW        // IT if distance <= LowThreshold
 * - RS_IT_ABOVE_HIGH       // IT if distance > HighThreshold
 * - RS_IT_EQUAL_LOW        // IT if distance == LowThreshold
 * - RS_IT_NOT_EQUAL_LOW    // IT if distance != LowThreshold
 */

/* Private typedef -----------------------------------------------------------*/

/* Private define ------------------------------------------------------------*/
#define SUCCESSIVE_MATRIX	8						/* How many successive matrix we get in our neai_buffer. Possible values: power of 2 between 1 and 64 */
#define MATRIX_RESOLUTION	64 						/* Possible values: 64 for 8x8 resolution, 16 for 4x4 resolution */
#define AXES				1						/* Possible value: 1 (distance data) */
#define NEAI_BUFFER_SIZE	(SUCCESSIVE_MATRIX * MATRIX_RESOLUTION * AXES)	/* The size of our NEAI buffer used for classification */
#define MIN_THRESHOLD		100						/* Minimum distance in mm between sensor & object to detect. Possible values: 40 to 4000 */
#define MAX_THRESHOLD		400 					/* Maximum distance in mm between sensor & object to detect. Possible values: 40 to 4000 */
#define NEAI_MODE			1						/* Possible values: 0 for data logging mode, 1 for NanoEdgeAI classification mode */

#if (SUCCESSIVE_MATRIX < 1) || (SUCCESSIVE_MATRIX > 64) || \
    ((SUCCESSIVE_MATRIX & (SUCCESSIVE_MATRIX - 1)) != 0)
#error SUCCESSIVE_MATRIX must be a power of two between 1 and 64
#endif
#if (MATRIX_RESOLUTION != 16) && (MATRIX_RESOLUTION != 64)
#error MATRIX_RESOLUTION must be 16 or 64
#endif
#if (AXES != 1) || ((NEAI_MODE != 0) && (NEAI_MODE != 1))
#error AXES must be 1 and NEAI_MODE must be 0 or 1
#endif
#if (MIN_THRESHOLD < 40) || (MAX_THRESHOLD > 4000) || (MIN_THRESHOLD > MAX_THRESHOLD)
#error Invalid distance thresholds
#endif
#if NEAI_MODE && (NEAI_BUFFER_SIZE != (NEAI_INPUT_SIGNAL_LENGTH * NEAI_INPUT_AXIS_NUMBER))
#error The sensor buffer must match the NanoEdgeAI model input size
#endif

/* Private variables ---------------------------------------------------------*/
static RANGING_SENSOR_Capabilities_t Cap;
static RANGING_SENSOR_ProfileConfig_t Profile;
static int32_t status = 0;
volatile uint8_t ToF_EventDetected = 0;
enum neai_state neai_status = 0;
float neai_buffer[NEAI_BUFFER_SIZE] = {0};
int id_class = 0; // Point to id class (see argument of neai_classification fct)
float output_class_buffer[NEAI_NUMBER_OF_CLASSES]; // Buffer of class probabilities


/* Private function prototypes -----------------------------------------------*/
static void MX_53L5A1_ThresholdDetection_Init(void);
static void MX_53L5A1_ThresholdDetection_Process(void);
static void CheckSensorStatus(int32_t sensor_status, const char *operation);

void MX_X_CUBE_TOF1_Init(void)
{
  /* USER CODE BEGIN SV */

  /* USER CODE END SV */

  /* USER CODE BEGIN X_CUBE_TOF1_Init_PreTreatment */

  /* USER CODE END X_CUBE_TOF1_Init_PreTreatment */

  /* Initialize the peripherals and the TOF components */

  MX_53L5A1_ThresholdDetection_Init();

  /* USER CODE BEGIN X_CUBE_TOF1_Init_PostTreatment */

  /* USER CODE END X_CUBE_TOF1_Init_PostTreatment */
}

/*
 * LM background task
 */
void MX_X_CUBE_TOF1_Process(void)
{
  /* USER CODE BEGIN X_CUBE_TOF1_Process_PreTreatment */

  /* USER CODE END X_CUBE_TOF1_Process_PreTreatment */

  MX_53L5A1_ThresholdDetection_Process();

  /* USER CODE BEGIN X_CUBE_TOF1_Process_PostTreatment */

  /* USER CODE END X_CUBE_TOF1_Process_PostTreatment */
}

static void MX_53L5A1_ThresholdDetection_Init(void)
{
  CheckSensorStatus(VL53L5A1_RANGING_SENSOR_Init(VL53L5A1_DEV_CENTER),
                    "VL53L5A1_RANGING_SENSOR_Init");
}

static void MX_53L5A1_ThresholdDetection_Process(void)
{
  uint32_t Id;
  uint8_t zones_per_line;

  RANGING_SENSOR_ITConfig_t ITConfig;
  RANGING_SENSOR_Result_t Result;

  CheckSensorStatus(VL53L5A1_RANGING_SENSOR_ReadID(VL53L5A1_DEV_CENTER, &Id),
                    "VL53L5A1_RANGING_SENSOR_ReadID");
  CheckSensorStatus(VL53L5A1_RANGING_SENSOR_GetCapabilities(VL53L5A1_DEV_CENTER, &Cap),
                    "VL53L5A1_RANGING_SENSOR_GetCapabilities");

#if MATRIX_RESOLUTION == 64
  Profile.RangingProfile = RS_PROFILE_8x8_CONTINUOUS;
#else
  Profile.RangingProfile = RS_PROFILE_4x4_CONTINUOUS;
#endif
  Profile.TimingBudget = 5; /* 5 ms < TimingBudget < 100 ms */
  Profile.Frequency = 15; /* Hz */
  Profile.EnableAmbient = 0; /* Enable: 1, Disable: 0 */
  Profile.EnableSignal = 1; /* Enable: 1, Disable: 0 */

  /* set the profile if different from default one */
  CheckSensorStatus(VL53L5A1_RANGING_SENSOR_ConfigProfile(VL53L5A1_DEV_CENTER, &Profile),
                    "VL53L5A1_RANGING_SENSOR_ConfigProfile");

  /* threshold parameters */
  ITConfig.Criteria = RS_IT_IN_WINDOW;
  ITConfig.LowThreshold = MIN_THRESHOLD; /* mm */
  ITConfig.HighThreshold = MAX_THRESHOLD; /* mm */

  CheckSensorStatus(VL53L5A1_RANGING_SENSOR_ConfigIT(VL53L5A1_DEV_CENTER, &ITConfig),
                    "VL53L5A1_RANGING_SENSOR_ConfigIT");

  status = VL53L5A1_RANGING_SENSOR_Start(VL53L5A1_DEV_CENTER, RS_MODE_ASYNC_CONTINUOUS);

  zones_per_line = ((Profile.RangingProfile == RS_PROFILE_8x8_AUTONOMOUS) ||
      (Profile.RangingProfile == RS_PROFILE_8x8_CONTINUOUS)) ? 8 : 4;

  CheckSensorStatus(status, "VL53L5A1_RANGING_SENSOR_Start");

  neai_status = neai_classification_init();
  if(neai_status != NEAI_OK) {
	  printf("ERROR NEAI classification init (%d)\r\n", (int)neai_status);
	  Error_Handler();
  }

  /* Reset ToF event variable to avoid starting log at boot */
  ToF_EventDetected = 0;

  while (1)
  {
  /* interrupt mode */
	  if (ToF_EventDetected != 0) {
		for (uint8_t i = 0; i < SUCCESSIVE_MATRIX; i++) {
			uint32_t start = HAL_GetTick();
			do {
				status = VL53L5A1_RANGING_SENSOR_GetDistance(VL53L5A1_DEV_CENTER, &Result);
				if ((status != BSP_ERROR_NONE) && ((HAL_GetTick() - start) >= 1000U)) {
					CheckSensorStatus(status, "VL53L5A1_RANGING_SENSOR_GetDistance");
				}
			} while(status != BSP_ERROR_NONE);
			if (Result.NumberOfZones != MATRIX_RESOLUTION) {
				printf("Unexpected VL53L5CX resolution: %lu\r\n", (unsigned long)Result.NumberOfZones);
				Error_Handler();
			}
			for (uint8_t j = 0; j < Result.NumberOfZones; j += zones_per_line) {
				for (int8_t k = (zones_per_line - 1); k >= 0; k--) {
					if (Result.ZoneResult[j+k].NumberOfTargets > 0) {
						neai_buffer[(i * MATRIX_RESOLUTION) + j + k] = (((float)Result.ZoneResult[j+k].Distance[0] > ITConfig.HighThreshold) || ((float)Result.ZoneResult[j+k].Distance[0] < ITConfig.LowThreshold)) ? 0.0 : (float)Result.ZoneResult[j+k].Distance[0];
					}
					else {
						/* If no target detected we set both distance & signal data to 0.0 */
						neai_buffer[(i * MATRIX_RESOLUTION) + j + k] = 0.0;
					}
				}
			}
		}

		if (NEAI_MODE) {
			/* Call NEAI classifier function in order to identify the phenomenom */
			neai_status = neai_classification(neai_buffer, output_class_buffer, &id_class);
			if (neai_status != NEAI_OK) {
				printf("ERROR NEAI classification (%d)\r\n", (int)neai_status);
				Error_Handler();
			}
			const char *class_name = neai_get_class_name(id_class);
			if (class_name == NULL) {
				printf("ERROR NEAI class ID: %d\r\n", id_class);
				Error_Handler();
			}
			printf("Class found: %s\r\n", class_name);
			HAL_Delay(500);
		}
		else {
			/* Print the whole buffer to the serial in order to log data */
			for (uint16_t i = 0; i < NEAI_BUFFER_SIZE; i++) {
				printf("%.1f ", neai_buffer[i]);
			}
			printf("\r\n");
		}
		/* Reset ToF event variable when log has been done successfully */
		ToF_EventDetected = 0;
	}
  }
}

static void CheckSensorStatus(int32_t sensor_status, const char *operation)
{
  if (sensor_status != BSP_ERROR_NONE)
  {
    printf("%s failed (%ld)\r\n", operation, (long)sensor_status);
    Error_Handler();
  }
}

#ifdef __cplusplus
}
#endif

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
