################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/BSP/53L5A1/53l5a1_ranging_sensor.c 

OBJS += \
./Drivers/BSP/53L5A1/53l5a1_ranging_sensor.o 

C_DEPS += \
./Drivers/BSP/53L5A1/53l5a1_ranging_sensor.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/BSP/53L5A1/%.o Drivers/BSP/53L5A1/%.su Drivers/BSP/53L5A1/%.cyclo: ../Drivers/BSP/53L5A1/%.c Drivers/BSP/53L5A1/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32L476xx -c -I../Inc -I../X-CUBE-TOF1/App -I../X-CUBE-TOF1/Target -I../Drivers/BSP/53L5A1 -I../Drivers/BSP/Components/Common -I../Drivers/BSP/Components/vl53l5cx -I../Drivers/BSP/Components/vl53l5cx/modules -I../Drivers/BSP/Components/vl53l5cx/porting -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Drivers-2f-BSP-2f-53L5A1

clean-Drivers-2f-BSP-2f-53L5A1:
	-$(RM) ./Drivers/BSP/53L5A1/53l5a1_ranging_sensor.cyclo ./Drivers/BSP/53L5A1/53l5a1_ranging_sensor.d ./Drivers/BSP/53L5A1/53l5a1_ranging_sensor.o ./Drivers/BSP/53L5A1/53l5a1_ranging_sensor.su

.PHONY: clean-Drivers-2f-BSP-2f-53L5A1

