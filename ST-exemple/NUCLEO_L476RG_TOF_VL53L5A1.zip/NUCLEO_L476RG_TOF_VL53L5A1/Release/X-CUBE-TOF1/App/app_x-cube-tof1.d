X-CUBE-TOF1/App/app_x-cube-tof1.o: ../X-CUBE-TOF1/App/app_x-cube-tof1.c \
 ../X-CUBE-TOF1/App/app_x-cube-tof1.h ../Inc/main.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal.h \
 ../Inc/stm32l4xx_hal_conf.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_rcc.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32L4xx/Include/stm32l4xx.h \
 ../Drivers/CMSIS/Device/ST/STM32L4xx/Include/stm32l476xx.h \
 ../Drivers/CMSIS/Include/core_cm4.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv7.h \
 ../Drivers/CMSIS/Device/ST/STM32L4xx/Include/system_stm32l4xx.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_rcc_ex.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_gpio.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_gpio_ex.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_dma.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_ll_dma.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_cortex.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_exti.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_flash.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_flash_ex.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_flash_ramfunc.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_i2c.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_i2c_ex.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_pwr.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_pwr_ex.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_uart.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_uart_ex.h \
 ../Drivers/BSP/53L5A1/53l5a1_ranging_sensor.h \
 ../Drivers/BSP/Components/Common/ranging_sensor.h \
 ../X-CUBE-TOF1/Target/53l5a1_conf.h ../Inc/stm32l4xx_nucleo_bus.h \
 ../Inc/stm32l4xx_nucleo_errno.h ../Inc/stm32l4xx_nucleo_errno.h \
 ../Drivers/BSP/Components/vl53l5cx/vl53l5cx.h \
 ../Drivers/BSP/Components/vl53l5cx/modules/vl53l5cx_api.h \
 ../Drivers/BSP/Components/vl53l5cx/porting/platform.h \
 ../Drivers/BSP/Components/vl53l5cx/modules/vl53l5cx_plugin_xtalk.h \
 ../Drivers/BSP/Components/vl53l5cx/modules/vl53l5cx_api.h \
 ../Drivers/BSP/Components/vl53l5cx/modules/vl53l5cx_plugin_detection_thresholds.h \
 ../X-CUBE-TOF1/Target/app_tof_pin_conf.h ../Inc/NanoEdgeAI.h
../X-CUBE-TOF1/App/app_x-cube-tof1.h:
../Inc/main.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal.h:
../Inc/stm32l4xx_hal_conf.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_rcc.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32L4xx/Include/stm32l4xx.h:
../Drivers/CMSIS/Device/ST/STM32L4xx/Include/stm32l476xx.h:
../Drivers/CMSIS/Include/core_cm4.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv7.h:
../Drivers/CMSIS/Device/ST/STM32L4xx/Include/system_stm32l4xx.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_rcc_ex.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_gpio.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_gpio_ex.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_dma.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_ll_dma.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_cortex.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_exti.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_flash.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_flash_ex.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_flash_ramfunc.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_i2c.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_i2c_ex.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_pwr.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_pwr_ex.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_uart.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_uart_ex.h:
../Drivers/BSP/53L5A1/53l5a1_ranging_sensor.h:
../Drivers/BSP/Components/Common/ranging_sensor.h:
../X-CUBE-TOF1/Target/53l5a1_conf.h:
../Inc/stm32l4xx_nucleo_bus.h:
../Inc/stm32l4xx_nucleo_errno.h:
../Inc/stm32l4xx_nucleo_errno.h:
../Drivers/BSP/Components/vl53l5cx/vl53l5cx.h:
../Drivers/BSP/Components/vl53l5cx/modules/vl53l5cx_api.h:
../Drivers/BSP/Components/vl53l5cx/porting/platform.h:
../Drivers/BSP/Components/vl53l5cx/modules/vl53l5cx_plugin_xtalk.h:
../Drivers/BSP/Components/vl53l5cx/modules/vl53l5cx_api.h:
../Drivers/BSP/Components/vl53l5cx/modules/vl53l5cx_plugin_detection_thresholds.h:
../X-CUBE-TOF1/Target/app_tof_pin_conf.h:
../Inc/NanoEdgeAI.h:
